# Vive el Hoy · Finanzas 360 — V232

## Cambios ejecutados

- `Tarjetas → Comparar beneficios`: corrección del fallo JavaScript por código fuera del ámbito de la aplicación. Se reubica el bloque de navegación dentro del mismo módulo principal, **reutilizando sin cambios `v144BenefitsPage`**, con sus cálculos, filtros, tabla, KPI y acciones originales. El acceso `Volver a Tarjetas` vuelve al portafolio. La pestaña separada Beneficios continúa fuera de la navegación.
- `Instituciones` en web: el selector bancario se alinea con el ancho del KPI global, usa tarjetas horizontales fluidas, icono a la izquierda, nombre y flecha a la derecha. Un clic abre el detalle original completo; otro clic en la misma institución cierra el detalle y elimina el espacio. No se alteró `bankDetail` ni `bankFigures` ni el HTML del KPI grande.
- Componentes entre módulos: se añadieron reglas CSS de compatibilidad que limitan el ancho de tablas y grids, evitan desbordamientos por hijos flexibles y mejoran el foco accesible y las transiciones reducidas, sin sustituir el lenguaje Liquid Glass.
- Navegación entre pestañas: entrar en Tarjetas desde Comparar beneficios recupera el portafolio y el estado interno se limpia al cambiar a otra sección bancaria.
- Los iconos PWA referenciados por el HTML y manifest se incluyen en el paquete de despliegue.

## Comprobaciones locales

- Sintaxis JavaScript principal y scripts secundarios: correcta.
- Navegador Chromium sin conexión a Supabase (datos de prueba en memoria): Instituciones cerrado/abierto/cerrado, detalle de productos, Comparar beneficios, vuelta a Tarjetas, sin errores JS.
- Resoluciones verificadas en pruebas locales: 1920×1080, 1440×900, 1280×800, 1024×768 y 390×844; sin desbordamiento horizontal de la página en los flujos evaluados.
- Se recorrieron por render 14 módulos adicionales en 1440, 1024 y 390 px sin errores JS en las pruebas locales.
- No se modificaron fórmulas financieras, tablas de Supabase ni datos de usuarios.

## Despliegue

- `Vive_el_Hoy_Finanzas_360_V232_Deploy_Web.zip`: publicar los archivos de la raíz en hosting web (Netlify o GitHub Pages según tu instalación).
- `Vive_el_Hoy_Finanzas_360_V232_Proyecto_Completo.zip`: copia íntegra del proyecto con la Edge Function previa preservada, sin modificar configuración ni secretos.
- `Vive_el_Hoy_Finanzas_360_V232_index.html`: archivo individual para reemplazo puntual.

### Límites de validación

No se probó con tu cuenta personal, tus datos reales, Supabase activo ni los permisos de usuario; tampoco se desplegó en un repositorio remoto. Las validaciones visuales y de interacción fueron locales con datos sintéticos. La importación de Apple Pay no fue modificada.
