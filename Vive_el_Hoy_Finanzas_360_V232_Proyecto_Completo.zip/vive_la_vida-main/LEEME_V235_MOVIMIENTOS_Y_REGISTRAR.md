# V235 — Movimientos y Registrar flotante

- Movimientos abre directamente el libro de operaciones, sin paneles de registro antiguos, sin selector duplicado.
- El botón azul Registrar movimiento sigue en la cabecera superior del libro.
- Registrar abre el asistente en una ventana flotante, sin abandonar la pantalla.
- El selector Recibir/Pagar/Mover/Otros cambia dentro de la ventana.
- El historial, filtros, edición, eliminación, borradores, operaciones y datos no han sido modificados.

Verificación realizada: sintaxis de scripts JavaScript y estructura del paquete. La prueba de navegador y sincronización con Supabase siguen pendientes.
