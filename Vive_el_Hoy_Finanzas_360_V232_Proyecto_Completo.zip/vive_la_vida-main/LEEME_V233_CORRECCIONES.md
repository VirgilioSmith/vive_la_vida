# vive el hoy · Finanzas 360 — V233

Actualización basada en el proyecto completo V232 recibido. Se conservan íntegros los recursos de Apple Pay, Supabase, PWA, iconos y las demás funcionalidades.

## 1. Registrar y Movimientos
- La navegación «Movimientos» mantiene el historial, controles y análisis existentes.
- El botón global «Registrar» presenta el asistente original («¿Qué necesitas hacer?»; Recibir/Pagar/Mover/Otros), tanto en escritorio como en móvil.
- No se cambian estilos, colores ni dimensiones del asistente.

## 2. Entre personas
- Editar/eliminar acuerdos en ambas direcciones: «me deben» y «yo debo».
- Editar capital, fecha, vencimiento, cuenta o tarjeta, dirección, concepto, notas y condiciones.
- Editar o eliminar entregas iniciales y abonos individuales desde la trazabilidad, conservando el resto.
- El cambio de capital sincroniza la entrega contable ya existente en lugar de duplicarla.
- Validaciones: un capital no puede ser inferior a abonos y condonaciones; un abono no puede exceder el saldo; no se permiten entregas iniciales duplicadas en el mismo acuerdo.
- Se crea un punto local de recuperación antes de cambiar o eliminar acuerdos y movimientos personales; las operaciones se revierten si no puede prepararse el guardado seguro.
- Las métricas se recalculan desde el libro contable, sin crear un gasto duplicado.

## 3. KPI principal grande
- Se mantienen las implementaciones y geometrías originales de «Tu posición financiera» en Resumen y del KPI ejecutivo principal en Instituciones.
- No se sustituye el KPI por una tarjeta pequeña ni se alteran sus fórmulas y presentación responsive preexistentes.

## Pruebas efectuadas
- Sintaxis JavaScript validada con Node.js para los scripts integrados.
- Pruebas de navegador Chromium con datos ficticios: navegación entre el asistente y Movimientos; KPI originales; edición de principal RD$1,000 -> RD$1,500; edición de abono RD$250 -> RD$300; eliminación de abono y de acuerdos en ambas direcciones; preservación de otros movimientos y saldos.
- Pruebas de controles móviles y validación de capital mínimo.

**Importante:** las pruebas contables se realizaron en un entorno aislado de navegador con datos ficticios. No se inició sesión ni se escribió en la cuenta de Supabase del usuario, por lo que la sincronización real con su cuenta debe validarse tras desplegarlo en su entorno. Realizar respaldo JSON antes de actualizar una instalación existente.
