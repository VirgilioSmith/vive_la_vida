# Vive el Hoy · Finanzas 360 — V236

## Instituciones, recuperación visual de las tarjetas completas

Sobre la base V235, la vista de Instituciones en escritorio vuelve a mostrar tarjetas grandes, en tres columnas cuando hay espacio (dos en pantallas medianas), con:

- Logotipo registrado o iniciales; nombre, tipo de institución y etiqueta Personal/Negocio.
- Número de productos vinculados; en entidades no bancarias, número de beneficios e ingresos activos vinculados.
- Fondos disponibles y deudas por institución, calculados con la función existente `bankFigures` en equivalente RD$.
- Filtros funcionales «Todas», «Bancos» y «No bancarias», y apertura/cierre del detalle de la institución al pulsar su tarjeta.
- Nota explicativa sobre beneficios no monetarios e importes históricos.

Se preservan el KPI grande existente en la parte superior, los perfiles Personal/Negocio, productos, transacciones, cuenta bancaria real, configuración, datos y la experiencia móvil actual. Las tarjetas toman logos y montos de los registros guardados, sin hardcodear cifras de la referencia visual.

## Pruebas

- Análisis sintáctico de los nueve scripts inline con Node.js.
- Pruebas de navegador con seis instituciones de demostración y sin conexión a backend: 1536x920 (3 columnas), 1024x850 (2 columnas) y 390x844 (vista móvil existente); sin errores JavaScript.
- Filtros y apertura de detalle comprobados; sin desbordamiento horizontal en los tamaños de escritorio probados.
- No se ejecutó prueba de persistencia real contra Supabase y no se publicó en GitHub o Netlify.
