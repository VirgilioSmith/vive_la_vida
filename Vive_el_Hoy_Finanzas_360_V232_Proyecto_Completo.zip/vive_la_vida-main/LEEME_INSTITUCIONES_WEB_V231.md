# Vive el Hoy · Finanzas 360 — Instituciones web V231

## Cambios
- Las tarjetas bancarias de escritorio usan una cuadrícula adaptable y conservan los logos y nombres.
- Clic en una tarjeta cerrada: abre sus indicadores, productos y acciones originales.
- Segundo clic en la misma tarjeta: oculta el panel completo sin dejar contenedores vacíos.
- Clic en otra tarjeta: sustituye el detalle anterior por la institución elegida.
- Cambiar filtro o perfil cierra el detalle en escritorio para evitar que reaparezca sin selección.
- El KPI global y toda su lógica no se modificaron.
- La pantalla móvil utiliza la implementación original.
- Conserva la integración previa Tarjetas → Comparar beneficios y Apple Pay.

## Publicación
El paquete contiene la aplicación web completa. Publica el contenido de `vive_la_vida-main/` en tu alojamiento, o sustituye el `index.html` del sitio por el nuevo archivo manteniendo el resto de los recursos.

## Validaciones realizadas
- Sintaxis de todos los scripts JS inline mediante Node.js.
- Verificación de que el bloque del KPI principal coincide con la versión de entrada.
- Verificación de que la función de renderizado móvil coincide con la versión de entrada.
- Confirmación estática del comportamiento de alternancia, panel condicional y CSS responsive.

No se pudo completar la ejecución visual interactiva en navegador (restricciones de esta sesión). No se publicó en GitHub ni en Netlify.
