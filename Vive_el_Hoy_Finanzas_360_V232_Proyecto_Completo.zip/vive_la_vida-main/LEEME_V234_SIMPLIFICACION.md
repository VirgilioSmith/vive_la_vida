# Vive el Hoy · Finanzas 360 — V234

Versión basada en el paquete completo V233. Cambios limitados a `index.html`:

1. **Cuentas bancarias:** se retira el encabezado «Cuentas y liquidez», sus cuatro tarjetas resumen y el panel de desglose asociado. Se mantienen las cuentas reales, las tarjetas individuales, el detalle por cuenta, el efectivo permanente y las acciones de alta, archivo y configuración.
2. **Tu catálogo:** se conserva la cabecera principal con el contador de categorías y el botón para crear nuevas. Se retiran las pestañas «Catálogo completo / Utilizadas / Sin clasificar», el banner descriptivo adicional y las cuatro métricas secundarias. Se mantienen las tablas de categorías de gastos e ingresos, la expansión de subcategorías y las acciones existentes.

No se cambian los esquemas de datos ni los cálculos del resto de los módulos. Se verificó la sintaxis de los bloques JavaScript. No se realizó prueba con la instancia Supabase real ni publicación a GitHub/Netlify. 
