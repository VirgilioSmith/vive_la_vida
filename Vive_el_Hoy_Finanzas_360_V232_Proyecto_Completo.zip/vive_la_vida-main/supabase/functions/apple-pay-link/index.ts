// Vive el Hoy — Administración de vínculos Apple Wallet.
// NO reemplazar con apple-pay-ingest: son rutas y credenciales distintas.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const CORS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, DELETE, OPTIONS",
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store",
};
const VERSION = "vive-apple-pay-link-fix-1.0.0";
const respond = (obj: Record<string, unknown>, status = 200) =>
  new Response(JSON.stringify({ ...obj, version: VERSION }), { status, headers: CORS });

async function sha256(raw: string) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(raw));
  return Array.from(new Uint8Array(digest), v => v.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  if (req.method !== "POST" && req.method !== "DELETE") {
    return respond({ ok: false, error: "Método no permitido" }, 405);
  }
  const jwt = /^Bearer\s+(.+)$/i.exec(req.headers.get("Authorization") ?? "")?.[1];
  if (!jwt) return respond({ ok: false, error: "Inicia sesión en Vive el Hoy" }, 401);
  const url = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !serviceRoleKey) return respond({ ok: false, error: "Configuración del servidor incompleta" }, 500);
  // La clave service_role permanece exclusivamente en el servidor.
  const admin = createClient(url, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data: authData, error: authError } = await admin.auth.getUser(jwt);
  const user = authData?.user;
  if (authError || !user) return respond({ ok: false, error: "Sesión inválida o vencida" }, 401);

  let body: unknown;
  try { body = await req.json(); } catch { return respond({ ok: false, error: "JSON inválido" }, 400); }
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return respond({ ok: false, error: "Request Body debe ser un objeto" }, 400);
  }
  const data = body as Record<string, unknown>;
  try {
    if (req.method === "POST") {
      const instrumentType = data.instrument_type;
      const instrumentId = data.instrument_id;
      const currency = data.currency;
      if (instrumentType !== "card" || typeof instrumentId !== "string" || !instrumentId.trim() ||
          (currency !== "DOP" && currency !== "USD")) {
        return respond({ ok: false, error: "Selecciona una tarjeta y una moneda válidas" }, 400);
      }
      const instrument = instrumentId.trim();
      // Seleccionar únicamente vínculos pertenecientes a este usuario.
      const { data: rows, error: readError } = await admin
        .from("apple_pay_links")
        .select("id,instrument_id,currency,active")
        .eq("user_id", user.id)
        .eq("instrument_type", "card")
        .eq("instrument_id", instrument)
        .eq("currency", currency)
        .order("created_at", { ascending: false })
        .limit(1);
      if (readError) throw readError;
      // La app guarda las tarjetas dentro del documento personal; su validación
      // exacta requiere auditar el formato de ese documento. Aquí se exige sesión
      // y el identificador de la tarjeta aportado por dicha sesión.
      const secret = `vh_${crypto.randomUUID().replaceAll("-", "")}_${crypto.randomUUID().replaceAll("-", "")}`;
      const tokenHash = await sha256(secret);
      const cardLabel = typeof data.card_label === "string" && data.card_label.trim()
        ? data.card_label.trim().slice(0, 100) : "Tarjeta vinculada";
      let result;
      if (rows?.length) {
        result = await admin.from("apple_pay_links")
          .update({ token_hash: tokenHash, active: true, card_label: cardLabel })
          .eq("id", rows[0].id).eq("user_id", user.id)
          .select("id").single();
      } else {
        result = await admin.from("apple_pay_links")
          .insert({ user_id: user.id, instrument_type: "card", instrument_id: instrument,
            currency, token_hash: tokenHash, card_label: cardLabel, active: true })
          .select("id").single();
      }
      if (result.error) throw result.error;
      return respond({ ok: true, link_id: result.data.id, token: secret,
        webhook_url: `${url}/functions/v1/apple-pay-ingest`,
        message: "Vínculo activo. Guarda el token nuevo en Atajos." });
    }
    const linkId = data.link_id;
    if (typeof linkId !== "string" || !/^[0-9a-f-]{36}$/i.test(linkId)) {
      return respond({ ok: false, error: "link_id inválido" }, 400);
    }
    // Revocar es reversible mediante nueva vinculación; no borra compras históricas.
    const { data: revoked, error: revokeError } = await admin.from("apple_pay_links")
      .update({ active: false })
      .eq("id", linkId).eq("user_id", user.id)
      .select("id").maybeSingle();
    if (revokeError) throw revokeError;
    if (!revoked) return respond({ ok: false, error: "Vinculación no encontrada" }, 404);
    return respond({ ok: true, link_id: revoked.id, active: false });
  } catch (err) {
    console.error("apple-pay-link:", err instanceof Error ? err.message : String(err));
    return respond({ ok: false, error: "Error administrando la vinculación; consulta los registros de apple-pay-link" }, 500);
  }
});
