# Vive el Hoy · Reparación de vinculación Apple Wallet

## Diagnóstico confirmado en el ZIP

- Los botones **Vincular tarjeta** y **Desvincular** llaman a `functions/v1/apple-pay-link` mediante POST y DELETE, enviando `Authorization: Bearer <sesión del usuario>`.
- Las compras usan otra función, `apple-pay-ingest`, con un encabezado independiente `X-Vive-Token`.
- Si **Vincular** o **Desvincular** reciben «Falta X-Vive-Token», hay un **desajuste de funciones en Supabase**: probablemente se publicó el código de ingest en la ruta de link (no puede verificarse desde este ZIP porque no incluye el backend desplegado).
- El archivo original del ZIP contenía únicamente `index.html`, `sw.js` y `manifest.webmanifest`. No incluía código de Edge Functions.

## Correcciones entregadas

1. `index.html`: ambas acciones usan una función compartida de peticiones a `apple-pay-link`, con errores claros, autenticación por sesión, manejo de fallos de red y estado de carga.
2. `supabase/functions/apple-pay-link/index.ts`: **nuevo backend para gestionar vínculos**, separado de ingest. Crea o renueva un vínculo, devuelve token NUEVO y URL de recepción, permite desactivar vinculaciones con DELETE sin borrar movimientos. Verifica la sesión mediante `auth.getUser` antes de usar la clave de servicio.
3. `PRUEBA_APPLE_PAY.json`: cuerpo de diagnóstico sin guardar compras, válido SOLO para `apple-pay-ingest` versión compatible con `dry_run`.
4. Se corrige el contador singular/plural y la documentación visible de la sección.

## Instalación necesaria (no basta con subir ZIP a Netlify o GitHub)

### A. Publicar la función que falta: `apple-pay-link`

1. En **Supabase → Edge Functions → apple-pay-link → Code**, haz copia de seguridad del `index.ts` existente.
2. Pega el contenido de `supabase/functions/apple-pay-link/index.ts` de este paquete, **no el código de `apple-pay-ingest`**.
3. Despliega (Deploy updates). En logs, busca la versión `vive-apple-pay-link-fix-1.0.0` al probar.
4. En la configuración de esa función, mantén `Verify JWT` activado si Supabase valida el JWT de la sesión web. El código también comprueba la identidad con `auth.getUser`. Si tu proyecto usa tokens que requieren desactivar la verificación de plataforma, el código **sigue exigiendo** Bearer JWT válido con `auth.getUser`.
5. `apple-pay-ingest` permanece **separada** y conserva su autenticación por `X-Vive-Token`. No la reemplaces con `apple-pay-link`.

### B. Publicar el frontend

Sube `index.html`, `sw.js` y `manifest.webmanifest` a tu despliegue existente (GitHub Pages/Netlify) respetando su estructura. Si actualizas el repositorio, incluye también el directorio `supabase/functions/apple-pay-link/` como fuente del backend para facilitar el mantenimiento.

### C. Comprobar

- Con sesión iniciada, en Ajustes → Apple Wallet, pulsa **Actualizar** y verifica las tarjetas existentes.
- Pulsa **Vincular tarjeta**, copia el token NUEVO, guárdalo en la automatización **Atajos** del iPhone (`X-Vive-Token`). Los tokens anteriores del vínculo renovado dejan de valer.
- Pulsa **Desvincular** para desactivar el vínculo. No se eliminan eventos históricos.
- Una vez validado el enlace, revisa la prueba de recepción **por separado** en `apple-pay-ingest` con `dry_run: true` y comprueba la importación de eventos `pending` antes de habilitar movimientos reales.

## Advertencias y límites

- El ZIP se inspeccionó y su JavaScript se revisó sintácticamente, pero no fue posible ejecutar pruebas de extremo a extremo contra tu Supabase ni el iPhone. El restablecimiento en producción depende de desplegar **ambas partes** en el proyecto correcto.
- La función de vinculación exige sesión válida y filtra por `user_id`; el identificador de la tarjeta se recibe desde el documento de la aplicación. La validación server-side de existencia de tarjeta requeriría modelar por separado las tarjetas o consultar su documento `jsonb`, cuyo esquema interno no se ha auditado.
- Un vínculo renovado produce una clave secreta nueva: actualizar Atajos es obligatorio. No expongas claves en capturas ni logs. Rota claves divulgadas anteriormente.
- El frontend importador deja que `apple_pay_events` pendientes se conviertan en movimientos cuando la app está activa; no se modificó su lógica financiera.
